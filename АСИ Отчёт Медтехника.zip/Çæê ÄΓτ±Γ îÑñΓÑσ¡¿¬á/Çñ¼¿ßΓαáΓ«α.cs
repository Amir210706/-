﻿using PK.controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using РК.controller;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace РК
{
    
        public partial class Адмистрация : Form
        {
            private void Адмистрация_Load(object sender, EventArgs e)
            {
                // Заполняем роли один раз при запуске формы
                comboBoxRoles.Items.Clear();
                comboBoxRoles.Items.AddRange(new string[] { "admin", "employee", "Director" });
            }

            private string currentAdminLogin;
            Query controller;
            public Адмистрация(string adminLogin = null)
            {
                InitializeComponent();
                currentAdminLogin = adminLogin;

                this.Load += new EventHandler(Form1_Load);
                controller = new Query(connectionstring.connect);

                label8.Visible = false;
                Update.Visible = false;
                Delete.Visible = false;
                comboBoxRoles.Visible = false;
                buttonChangeRole.Visible = false;

                comboBoxRoles.Items.AddRange(new string[] { "admin", "employee", "Director" });
                buttonChangeRole.Click += BtnChangeRole_Click;
            }

            private void adminLogOut_Click(object sender, EventArgs e)
            {
                Login_app form2 = new Login_app();
                form2.Show();
                this.Close();
            }

            private void Update_Click(object sender, EventArgs e)
            {
                if (comboBox1.SelectedItem == null)
                {
                    MessageBox.Show("Пожалуйста, выберите таблицу из списка.");
                    return;
                }

                string selectedTable = comboBox1.SelectedItem.ToString();
                string path = Application.StartupPath + @"\Медтехника.accdb";
                string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    try
                    {
                        if (selectedTable == "Аккаунты")
                        {
                            // Получаем все столбцы таблицы Аккаунты
                            string query = $"SELECT * FROM [{selectedTable}]";
                            OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                            DataTable table = new DataTable();
                            adapter.Fill(table);

                            // Создаем новую таблицу без столбцов "зарплата" и "телефон"
                            DataTable filteredTable = new DataTable();

                            // Копируем только нужные столбцы
                            foreach (DataColumn column in table.Columns)
                            {
                                string columnName = column.ColumnName.ToLower();
                                if (columnName != "зарплата" && columnName != "телефон")
                                {
                                    filteredTable.Columns.Add(column.ColumnName, column.DataType);
                                }
                            }

                            // Копируем данные
                            foreach (DataRow row in table.Rows)
                            {
                                DataRow newRow = filteredTable.NewRow();
                                foreach (DataColumn column in filteredTable.Columns)
                                {
                                    newRow[column.ColumnName] = row[column.ColumnName];
                                }
                                filteredTable.Rows.Add(newRow);
                            }

                            dataGridView1.DataSource = filteredTable;

                            // Показываем предупреждение для текущего админа
                            ShowAdminWarning();
                        }
                        else
                        {
                            string query = $"SELECT * FROM [{selectedTable}]";
                            OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                            DataTable table = new DataTable();
                            adapter.Fill(table);
                            dataGridView1.DataSource = table;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
                    }
                }
            }

            // Метод для показа предупреждения о том, что админ не может изменить свою роль
            private void ShowAdminWarning()
            {
                if (!string.IsNullOrEmpty(currentAdminLogin))
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (row.Cells["Логин"].Value != null)
                        {
                            string login = row.Cells["Логин"].Value.ToString();
                            if (login.Trim().Equals(currentAdminLogin.Trim(), StringComparison.OrdinalIgnoreCase))
                            {
                                row.DefaultCellStyle.BackColor = Color.LightYellow;
                                row.DefaultCellStyle.ForeColor = Color.DarkGray;
                                break;
                            }
                        }
                    }
                }
            }

            private void Delete_Click(object sender, EventArgs e)
            {
                if (dataGridView1.CurrentRow == null)
                {
                    MessageBox.Show("Пожалуйста, выберите запись для удаления.", "Не выбрана запись", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult result = MessageBox.Show(
                    "Вы уверены, что хотите удалить выбранную запись?","Подтверждение удаления",MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

                if (result != DialogResult.Yes)
                {
                    return;
                }

                DataGridViewRow currentRow = dataGridView1.Rows[dataGridView1.CurrentRow.Index];

                if (comboBox1.Text == "Аккаунты")
                {
                    var loginCell = currentRow.Cells["Логин"];
                    if (loginCell != null && loginCell.Value != null)
                    {
                        string login = loginCell.Value.ToString();

                        // Проверка: админ не может удалить сам себя
                        if (!string.IsNullOrEmpty(currentAdminLogin) && login.Trim().Equals(currentAdminLogin.Trim(), StringComparison.OrdinalIgnoreCase))
                        {
                            MessageBox.Show("Вы не можете удалить свою собственную учетную запись!", "Запрещено", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    var idCell = currentRow.Cells["ID_сотрудника"];
                    if (idCell == null || idCell.Value == null)
                    {
                        MessageBox.Show("Не удалось определить ID сотрудника.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    try
                    {
                        int employeeId = int.Parse(idCell.Value.ToString());
                        controller.Delete1(employeeId);

                        Update_Click(sender, e);

                        MessageBox.Show("Запись успешно удалена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (comboBox1.Text == "Медтехники")
                {
                    controller.Delete2(int.Parse(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells["ID_Медтехника"].Value.ToString()));
                }
            }

            private void Form1_Load(object sender, EventArgs e)
            {
                this.Width = 960;
                this.Height = 365;
                try
                {
                    string path = Application.StartupPath + @"\Медтехника.accdb";
                    string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

                    using (OleDbConnection connection = new OleDbConnection(connectionString))
                    {
                        connection.Open();
                        DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        comboBox1.Items.Clear();

                        foreach (DataRow row in schemaTable.Rows)
                        {
                            string tableType = row["TABLE_TYPE"].ToString();
                            string tableName = row["TABLE_NAME"].ToString();

                            if (tableType == "TABLE" && tableName != "Заказы")
                            {
                                comboBox1.Items.Add(tableName);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }

            private void Exit_Click(object sender, EventArgs e)
            {
                Login_app form2 = new Login_app();
                form2.Show();
                this.Close();
            }

            private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
            {
                if (comboBox1.Text == "Аккаунты")
                {
                    label8.Visible = true;
                    Update.Visible = true;
                    Delete.Visible = true;
                    comboBoxRoles.Visible = true;
                    buttonChangeRole.Visible = true;
                    label8.Text = "Роли";
                }
                else if (comboBox1.Text == "Медтехники")
                {
                    label8.Visible = false;
                    Update.Visible = true;
                    Delete.Visible = true;
                    comboBoxRoles.Visible = false;
                    buttonChangeRole.Visible = false;
                    label8.Text = string.Empty;
                }
            }

            private void BtnChangeRole_Click(object sender, EventArgs e)
            {
                if (dataGridView1.CurrentRow == null)
                {
                    MessageBox.Show("Выберите пользователя для изменения роли.");
                    return;
                }

                var idCell = dataGridView1.CurrentRow.Cells["ID_сотрудника"];
                if (idCell == null || idCell.Value == null)
                {
                    MessageBox.Show("Не удалось определить ID выбранного пользователя.");
                    return;
                }

                int userId;
                if (!int.TryParse(idCell.Value.ToString(), out userId))
                {
                    MessageBox.Show("Некорректный ID пользователя.");
                    return;
                }

                var loginCell = dataGridView1.CurrentRow.Cells["Логин"];
                if (loginCell == null || loginCell.Value == null)
                {
                    MessageBox.Show("Не удалось определить логин выбранного пользователя.");
                    return;
                }
                string selectedUserLogin = loginCell.Value.ToString();

                // ПРОВЕРКА: Если админ пытается изменить свою собственную роль
                if (!string.IsNullOrEmpty(currentAdminLogin) && selectedUserLogin.Trim().Equals(currentAdminLogin.Trim(), StringComparison.OrdinalIgnoreCase))
                {
                     
                return;
                }

                string newRole = comboBoxRoles.SelectedItem?.ToString();

                if (string.IsNullOrEmpty(newRole))
                {
                    MessageBox.Show("Пожалуйста, выберите новую роль.");
                    return;
                }

                string path = Application.StartupPath + @"\Медтехника.accdb";
                string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    try
                    {
                        string updateQuery = "UPDATE [Аккаунты] SET [Роли] = @Роли WHERE [ID_сотрудника] = @id";
                        OleDbCommand cmd = new OleDbCommand(updateQuery, connection);
                        cmd.Parameters.AddWithValue("@Роли", newRole);
                        cmd.Parameters.AddWithValue("@id", userId);
                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Роль успешно обновлена.");
                            // Обновляем данные в dataGridView1
                            Update_Click(sender, e);
                        }
                        else
                        {
                            MessageBox.Show("Не удалось обновить роль. Проверьте выбранного пользователя.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при обновлении: " + ex.Message);
                    }
                }
            }

            private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
            {
                if (e.RowIndex >= 0 && comboBox1.Text == "Аккаунты")
                {
                    var loginCell = dataGridView1.Rows[e.RowIndex].Cells["Логин"];
                    if (loginCell != null && loginCell.Value != null)
                    {
                        string login = loginCell.Value.ToString();

                        // Блокируем comboBoxRoles если выбран текущий админ
                        if (!string.IsNullOrEmpty(currentAdminLogin) && login.Trim().Equals(currentAdminLogin.Trim(), StringComparison.OrdinalIgnoreCase))
                        {
                            comboBoxRoles.Enabled = false;
                            buttonChangeRole.Enabled = false;
                            MessageBox.Show("Вы не можете изменить свою собственную роль.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            comboBoxRoles.Enabled = true;
                            buttonChangeRole.Enabled = true;
                        }
                    }
                }
            }

            private void Адмистрация_Load_1(object sender, EventArgs e)
            {
            }
        }
    }

