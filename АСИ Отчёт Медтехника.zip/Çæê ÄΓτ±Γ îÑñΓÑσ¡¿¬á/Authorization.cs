﻿using PK.controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using РК.controller;

namespace РК
{
    public partial class Authorization : Form
    {
        public Authorization()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Query command = new Query(connectionstring.connect);
            if (command.Autorization(login.Text, passw.Text))
            {
                string role = command.roleCheck(login.Text, passw.Text);
                string userLogin = login.Text; // Сохраняем логин пользователя

                if (role == "admin")
                {
                    // Передаем логин текущего администратора в конструктор
                    Адмистрация form1 = new Адмистрация(userLogin);
                    form1.Show();
                    this.Close();
                }
                else if (role == "Director")
                {
                    Директор form5 = new Директор();
                    form5.Show();
                    this.Close();
                }
                else if (role == "employee")
                {
                    string employeeLogin = login.Text;
                    Сотрудник clientForm = new Сотрудник(employeeLogin);
                    clientForm.Show();
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Введен неверный логин или пароль", "Ошибка ",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login_app form8 = new Login_app();
            form8.Show();
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox1.Checked)
            {
                passw.UseSystemPasswordChar = false; 


            }
            else
            {
                passw.UseSystemPasswordChar = true;
                
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
