﻿using PK.controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using РК.controller;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace РК
{
    public partial class Адмистрация : Form
    {
        private void Адмистрация_Load(object sender, EventArgs e)
        {
            comboBoxRoles.Items.Clear();
            comboBoxRoles.Items.AddRange(new string[] { "admin", "employee", "Director" });
        }

        private string currentAdminLogin;
        Query controller;

        public Адмистрация(string adminLogin = null)
        {
            InitializeComponent();
            currentAdminLogin = adminLogin;

            label1.BackColor = System.Drawing.Color.Transparent;
            label2.BackColor = System.Drawing.Color.Transparent;
            label3.BackColor = System.Drawing.Color.Transparent;
           
            label6.BackColor = System.Drawing.Color.Transparent;
            label7.BackColor = System.Drawing.Color.Transparent;
            label9.BackColor = System.Drawing.Color.Transparent;
            label10.BackColor = System.Drawing.Color.Transparent;
            label8.BackColor = System.Drawing.Color.Transparent;

            this.Load += new EventHandler(Form1_Load);
            controller = new Query(connectionstring.connect);

            label1.Visible = false; textBox1.Visible = false;
            label2.Visible = false; textBox2.Visible = false;
            label3.Visible = false; maskedTextBox1.Visible = false; 

            label9.Visible = false;
            label10.Visible = false;
            label8.Visible = false;

            
            Delete.Visible = false;
            comboBoxRoles.Visible = false;
            BtnChange.Visible = false;

            comboBoxRoles.Items.AddRange(new string[] { "admin", "employee", "Director", "user" });
        }

      

        private string FormatPhone(string digits)
        {
            if (string.IsNullOrEmpty(digits)) return string.Empty;
            string clean = new string(digits.Where(char.IsDigit).ToArray());
            if (clean.Length == 11 && clean.StartsWith("7"))
                clean = clean.Substring(1);
            if (clean.Length == 10)
                return $"+7({clean.Substring(0, 3)}){clean.Substring(3, 3)}-{clean.Substring(6, 2)}-{clean.Substring(8, 2)}";
            return digits;
        }

        private string GetPhoneDigits(string input)
        {
            if (string.IsNullOrEmpty(input)) return string.Empty;
            string digits = new string(input.Where(char.IsDigit).ToArray());
            if (digits.Length == 11 && digits.StartsWith("7"))
                digits = digits.Substring(1);
            return digits;
        }

        private bool IsValidPhone(string input)
        {
            string digits = new string(input.Where(char.IsDigit).ToArray());
            return digits.Length == 10 || (digits.Length == 11 && digits.StartsWith("7"));
        }

        private void adminLogOut_Click(object sender, EventArgs e)
        {
            Login_app form2 = new Login_app();
            form2.Show();
            this.Close();
        }

        private void LoadTableData(string tableName)
        {
            //  Защита от пустого имени таблицы
            if (string.IsNullOrEmpty(tableName))
            {
                dataGridView1.DataSource = null;
                return;
            }

            string path = Application.StartupPath + @"\Медтехника.accdb";
            string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    string query = $"SELECT * FROM [{tableName}]";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    // Форматируем телефон для таблицы "Аккаунт"
                    if (tableName == "Аккаунт" && table.Columns.Contains("Телефон"))
                    {
                        foreach (DataRow row in table.Rows)
                        {
                            if (row["Телефон"] != DBNull.Value)
                            {
                                string phone = row["Телефон"].ToString();
                                row["Телефон"] = FormatPhone(phone);
                            }
                        }
                    }

                    dataGridView1.DataSource = table;

                    // Очищаем поля ввода
                    textBox1.Text = string.Empty;
                    textBox2.Text = string.Empty;
                    maskedTextBox1.Text = string.Empty;
                    maskedTextBox1.BackColor = SystemColors.Window;
                    comboBoxRoles.Enabled = true;
                    comboBoxRoles.BackColor = SystemColors.Window;
                    label10.Visible = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
                }
            }

            
        }
        private void Delete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.IsNewRow)
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.", "Не выбрана запись",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show(
                "Вы уверены, что хотите удалить выбранную запись?\nЭто действие нельзя отменить.",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);

            if (result != DialogResult.Yes) return;

            string selectedTable = comboBox1.Text;
            string path = Application.StartupPath + @"\Медтехника.accdb";
            string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    OleDbTransaction transaction = connection.BeginTransaction();

                    try
                    {
                        DataGridViewRow currentRow = dataGridView1.CurrentRow;

                        if (selectedTable == "Аккаунт")
                        {
                            var loginCell = currentRow.Cells["Логин"];
                            if (loginCell?.Value != null)
                            {
                                string login = loginCell.Value.ToString();
                                if (!string.IsNullOrEmpty(currentAdminLogin) && login == currentAdminLogin)
                                {
                                    MessageBox.Show("Вы не можете удалить свою собственную учетную запись!", "Запрещено",
                                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return;
                                }
                            }

                            var idCell = currentRow.Cells["ID_Аккаунт"];
                            if (idCell?.Value == null)
                            {
                                MessageBox.Show("Не удалось определить ID записи.", "Ошибка",
                                               MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            int accountId = Convert.ToInt32(idCell.Value);
                            string deleteQuery = "DELETE FROM [Аккаунт] WHERE [ID_Аккаунт] = @ID_Аккаунт";
                            using (OleDbCommand cmd = new OleDbCommand(deleteQuery, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@ID_Аккаунт", accountId);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        else if (selectedTable == "Медтехника")
                        {
                            var idCell = currentRow.Cells["ID_Товар"] ?? currentRow.Cells["Код"] ?? currentRow.Cells["ID"];
                            if (idCell?.Value == null)
                            {
                                MessageBox.Show("Не удалось определить ID товара.", "Ошибка",
                                               MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                            int itemId = Convert.ToInt32(idCell.Value);
                            string deleteQuery = "DELETE FROM [Медтехника] WHERE [ID_Товар] = @ID_Товар";
                            using (OleDbCommand cmd = new OleDbCommand(deleteQuery, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@ID_Товар", itemId);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            string keyColumn = null;
                            foreach (string possibleKey in new[] { "ID", "ID_Аккаунт", "ID_Товар", "ID_Сотрудник", "Код" })
                            {
                                if (currentRow.Cells[possibleKey]?.Value != null)
                                {
                                    keyColumn = possibleKey;
                                    break;
                                }
                            }

                            if (string.IsNullOrEmpty(keyColumn) || currentRow.Cells[keyColumn]?.Value == null)
                            {
                                MessageBox.Show($"Не удалось определить первичный ключ для таблицы \"{selectedTable}\".", "Ошибка",
                                               MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            int recordId = Convert.ToInt32(currentRow.Cells[keyColumn].Value);
                            string deleteQuery = $"DELETE FROM [{selectedTable}] WHERE [{keyColumn}] = @ID";
                            using (OleDbCommand cmd = new OleDbCommand(deleteQuery, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@ID", recordId);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();
                        LoadTableData(selectedTable);
                        MessageBox.Show("Запись успешно удалена.", "Успех",
                                       MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch
                    {
                        transaction?.Rollback();
                        throw;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Width = 960;
            this.Height = 365;

            try
            {
                string path = Application.StartupPath + @"\Медтехника.accdb";
                string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    comboBox1.Items.Clear();

                    foreach (DataRow row in schemaTable.Rows)
                    {
                        string tableType = row["TABLE_TYPE"].ToString();
                        string tableName = row["TABLE_NAME"].ToString();

                        if (tableType == "TABLE" && tableName != "Заказы" && !tableName.ToLower().Contains("сотрудник"))
                        {
                            comboBox1.Items.Add(tableName);
                        }
                    }
                }

                // 👇 АВТОВЫБОР ПЕРВОЙ ТАБЛИЦЫ И ЗАГРУЗКА ДАННЫХ
                if (comboBox1.Items.Count > 0)
                {
                    comboBox1.SelectedIndex = 0; // Это автоматически вызовет comboBox1_SelectedIndexChanged
                }
                else
                {
                    // Если таблиц нет — покажем сообщение и очистим DataGridView
                    dataGridView1.DataSource = null;
                    MessageBox.Show("Доступные таблицы не найдены.", "Информация",
                                   MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Login_app form2 = new Login_app();
            form2.Show();
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedTable = comboBox1.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedTable)) return;

            if (selectedTable == "Аккаунт")
            {
                // Показываем поля
                label1.Visible = true; textBox1.Visible = true;
                label2.Visible = true; textBox2.Visible = true;
                label3.Visible = true; maskedTextBox1.Visible = true;
                label9.Visible = true;
                label10.Visible = true;
            
                label8.Visible = true;

                // Подписи
                label1.Text = "Логин";
                label2.Text = "Пароль";
                label3.Text = "Телефон";
                label7.Text = "Таблица Аккаунт";
                label8.Text = "Роли";
                label10.Text = " ";

                // Кнопки
                Delete.Visible = true;
                comboBoxRoles.Visible = true;
                BtnChange.Visible = true;

                //  Автозагрузка данных
                LoadTableData("Аккаунт");
            }
            else if (selectedTable == "Медтехника")
            {
                // Скрываем лишние поля
                label1.Visible = false; textBox1.Visible = false;
                label2.Visible = false; textBox2.Visible = false;
                label3.Visible = false; maskedTextBox1.Visible = false;
                label9.Visible = false;
                label10.Visible = false;
                label8.Visible = false;

           
                label7.Text = "Таблица Медтехники";
                label8.Text = string.Empty;

                // Кнопки
                Delete.Visible = false;
                comboBoxRoles.Visible = false;
                BtnChange.Visible = false;

                //  Автозагрузка данных
                LoadTableData("Медтехника");
            }
        }

        private void BtnChange_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Выберите пользователя для изменения.");
                return;
            }

            var idCell = dataGridView1.CurrentRow.Cells["ID_Аккаунт"];
            if (idCell == null || idCell.Value == null)
            {
                MessageBox.Show("Не удалось определить ID выбранного пользователя.");
                return;
            }

            int userId;
            if (!int.TryParse(idCell.Value.ToString(), out userId))
            {
                MessageBox.Show("Некорректный ID пользователя.");
                return;
            }

            var loginCell = dataGridView1.CurrentRow.Cells["Логин"];
            if (loginCell == null || loginCell.Value == null)
            {
                MessageBox.Show("Не удалось определить логин выбранного пользователя.");
                return;
            }
            string currentLogin = loginCell.Value.ToString();
            bool isOwnAccount = (!string.IsNullOrEmpty(currentAdminLogin) && currentLogin == currentAdminLogin);

            string newLogin = textBox1.Text.Trim();
            string Password = textBox2.Text.Trim();

            //  Получаем телефон из maskedTextBox1
            string phoneInput = maskedTextBox1.Text.Trim();
            string Telephone = GetPhoneDigits(phoneInput); // 9674674434

            string newRole = comboBoxRoles.SelectedItem?.ToString();
            List<string> changes = new List<string>();

            if (!string.IsNullOrEmpty(newLogin) && newLogin != currentLogin)
            {
                if (isOwnAccount)
                {
                    MessageBox.Show("Вы не можете изменить свой собственный логин!", "Запрещено",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (newLogin.Length < 3)
                {
                    MessageBox.Show("Логин должен содержать минимум 3 символа.", "Некорректный логин",
                                   MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                changes.Add("логин");
            }

            if (!string.IsNullOrEmpty(Password))
            {
                if (Password.Length < 4)
                {
                    MessageBox.Show("Пароль должен содержать минимум 4 символа.", "Ненадежный пароль",
                                   MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                changes.Add("пароль");
            }

            if (!string.IsNullOrEmpty(newRole) && newRole != comboBoxRoles.Text)
            {
                if (isOwnAccount)
                {
                    MessageBox.Show("Вы не можете изменить свою собственную роль!", "Запрещено",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                changes.Add("роль");
            }

            //  Проверка телефона
            if (!string.IsNullOrEmpty(phoneInput) && !maskedTextBox1.MaskCompleted)
            {
                MessageBox.Show("Введите корректный номер телефона в формате +7(XXX)XXX-XX-XX.", "Ошибка",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                maskedTextBox1.Focus();
                return;
            }

            if (!string.IsNullOrEmpty(phoneInput) && !string.IsNullOrEmpty(Telephone))
            {
                changes.Add("телефон");
            }

            if (changes.Count == 0)
            {
                MessageBox.Show("Нет данных для изменения. Введите новые данные.");
                return;
            }

            string path = Application.StartupPath + @"\Медтехника.accdb";
            string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    if (changes.Contains("логин"))
                    {
                        string checkQuery = "SELECT COUNT(*) FROM [Аккаунт] WHERE [Логин] = @Логин AND [ID_Аккаунт] != @ID_Аккаунт";
                        using (OleDbCommand checkCmd = new OleDbCommand(checkQuery, connection))
                        {
                            checkCmd.Parameters.AddWithValue("@Логин", newLogin);
                            checkCmd.Parameters.AddWithValue("@ID_Аккаунт", userId);
                            int count = (int)checkCmd.ExecuteScalar();
                            if (count > 0)
                            {
                                MessageBox.Show("Этот логин уже используется другим пользователем.");
                                return;
                            }
                        }
                    }

                    string updateQuery = "UPDATE [Аккаунт] SET ";
                    List<OleDbParameter> parameters = new List<OleDbParameter>();

                    if (changes.Contains("логин") && !isOwnAccount)
                    {
                        updateQuery += "[Логин] = @Логин, ";
                        parameters.Add(new OleDbParameter("@Логин", newLogin));
                    }

                    if (changes.Contains("пароль"))
                    {
                        updateQuery += "[Пароль] = @Пароль, ";
                        parameters.Add(new OleDbParameter("@Пароль", Password));
                    }

                    if (changes.Contains("телефон"))
                    {
                        updateQuery += "[Телефон] = @Телефон, ";
                        parameters.Add(new OleDbParameter("@Телефон", Telephone)); // 9674674434
                    }

                    if (changes.Contains("роль") && !isOwnAccount)
                    {
                        updateQuery += "[Роли] = @Роли, ";
                        parameters.Add(new OleDbParameter("@Роли", newRole));
                    }

                    updateQuery = updateQuery.TrimEnd(',', ' ');
                    updateQuery += " WHERE [ID_Аккаунт] = @ID_Аккаунт";
                    parameters.Add(new OleDbParameter("@ID_Аккаунт", userId));

                    using (OleDbCommand cmd = new OleDbCommand(updateQuery, connection))
                    {
                        cmd.Parameters.AddRange(parameters.ToArray());
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            string message = "Данные успешно обновлены:\n";
                            foreach (var change in changes)
                            {
                                if ((change == "логин" || change == "роль") && isOwnAccount)
                                    continue;
                                message += $"• {change}\n";
                            }
                            if (isOwnAccount && changes.Contains("пароль"))
                                message += "\nВаш пароль был изменен. Используйте новый пароль.";

                            MessageBox.Show(message, "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadTableData("Аккаунт");
                        }
                        else
                        {
                            MessageBox.Show("Не удалось обновить данные.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при обновлении: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && comboBox1.Text == "Аккаунт")
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                string login = row.Cells["Логин"]?.Value?.ToString() ?? "";
                bool isOwnAccount = (!string.IsNullOrEmpty(currentAdminLogin) && login == currentAdminLogin);

                textBox1.Text = login;

                if (isOwnAccount)
                {
                    textBox1.ReadOnly = true;
                    textBox1.BackColor = Color.LightGray;
                    textBox1.ForeColor = Color.DarkBlue;
                    label1.Text = "Логин (нельзя изменить)";
                }
                else
                {
                    textBox1.ReadOnly = false;
                    textBox1.BackColor = SystemColors.Window;
                    textBox1.ForeColor = SystemColors.WindowText;
                    label1.Text = "Логин";
                }

                textBox2.Text = row.Cells["Пароль"]?.Value?.ToString() ?? "";

                //  Телефон: форматируем для отображения в maskedTextBox1
                string phoneFromDb = row.Cells["Телефон"]?.Value?.ToString() ?? "";
                string formattedPhone = FormatPhone(phoneFromDb); // +7(967)467-44-34

                // Устанавливаем в MaskedTextBox — он автоматически применит маску
                maskedTextBox1.Text = formattedPhone;
                // Если нужно, чтобы пользователь мог редактировать с нуля:
                // maskedTextBox1.Text = phoneFromDb.Length == 10 ? formattedPhone : string.Empty;

                string currentRole = row.Cells["Роли"]?.Value?.ToString() ?? "";
                comboBoxRoles.SelectedItem = currentRole;

                if (isOwnAccount)
                {
                    comboBoxRoles.Enabled = false;
                    comboBoxRoles.BackColor = Color.LightGray;
                    label8.Text = "Роль (нельзя изменить)";
                    label10.Text = $"Ваш аккаунт: {login}";
                    label10.ForeColor = Color.Blue;
                    label10.Visible = true;
                }
                else
                {
                    comboBoxRoles.Enabled = true;
                    comboBoxRoles.BackColor = SystemColors.Window;
                    label8.Text = "Роли";

                    string roleName = "";
                    switch (currentRole.ToLower())
                    {
                        case "user": roleName = "Клиент"; break;
                        case "admin": roleName = "Администратор"; break;
                        case "employee": roleName = "Сотрудник"; break;
                        case "director": roleName = "Директор"; break;
                        default: roleName = "Неизвестная роль"; break;
                    }

                    label10.Text = $"Аккаунт: {login} ({roleName})";
                    label10.ForeColor = Color.DarkGreen;
                    label10.Visible = true;
                }
            }
        }

        private void Адмистрация_Load_1(object sender, EventArgs e) { }
    }
}
