﻿using PK.controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace РК
{
    public partial class Register : Form
    {
        private Query controller;
        private string connectionString;

        public Register()
        {
            InitializeComponent();
            this.Load += new EventHandler(Register_Load);

            string path = Application.StartupPath + @"\Медтехника.accdb";
            connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";
            controller = new Query(connectionString);

            label1.BackColor = System.Drawing.Color.Transparent;
            label2.BackColor = System.Drawing.Color.Transparent;
            label3.BackColor = System.Drawing.Color.Transparent;
            label4.BackColor = System.Drawing.Color.Transparent;
            label5.BackColor = System.Drawing.Color.Transparent;
            label6.BackColor = System.Drawing.Color.Transparent;


        }

        private void Register_Load(object sender, EventArgs e)
        {
            // Настройка MaskedTextBox для телефона
            maskedTextBox1.Mask = "+7(000)000-00-00";
            maskedTextBox1.PromptChar = '_';
            maskedTextBox1.AsciiOnly = false;
            maskedTextBox1.BeepOnError = true;
            maskedTextBox1.RejectInputOnFirstFailure = true;
            maskedTextBox1.BackColor = System.Drawing.Color.White;
        }

        // Вспомогательный метод: получение только цифр из номера телефона
        private string GetPhoneDigits(string maskedPhone)
        {
            string digits = new string(maskedPhone.Where(char.IsDigit).ToArray());
            // Если номер начинается с 7 и имеет 11 цифр — убираем код страны для хранения
            if (digits.Length == 11 && digits.StartsWith("7"))
            {
                digits = digits.Substring(1);
            }
            return digits;
        }

        // Вспомогательный метод: валидация российского номера
        private bool IsValidRussianPhone(string maskedPhone)
        {
            string digits = new string(maskedPhone.Where(char.IsDigit).ToArray());
            return (digits.Length == 11 && digits.StartsWith("7")) ||
                   (digits.Length == 10 && digits.StartsWith("9"));
        }

        private void Register1_Click(object sender, EventArgs e)
        {
            string lastName = txtLastName.Text.Trim();
            string firstName = txtName.Text.Trim();
            string middleName = txtMiddleName.Text.Trim();

            // Получаем и валидируем телефон
            string phoneRaw = maskedTextBox1.Text;

            if (!maskedTextBox1.MaskCompleted)
            {
                MessageBox.Show("Пожалуйста, введите корректный номер телефона.");
                maskedTextBox1.Focus();
                return;
            }

            if (!IsValidRussianPhone(phoneRaw))
            {
                MessageBox.Show("Введите корректный российский номер телефона.");
                maskedTextBox1.Focus();
                return;
            }

            // Сохраняем только цифры (10 цифр)
            string phone = GetPhoneDigits(phoneRaw);

            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();

            // Валидация обязательных полей
            if (string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(firstName) ||
                string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                return;
            }

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                OleDbTransaction transaction = null;

                try
                {
                    transaction = connection.BeginTransaction();

                    // Проверяем, существует ли уже такой логин
                    string checkLoginQuery = "SELECT COUNT(*) FROM [Аккаунт] WHERE [Логин] = @Логин";
                    using (OleDbCommand cmdCheck = new OleDbCommand(checkLoginQuery, connection, transaction))
                    {
                        cmdCheck.Parameters.AddWithValue("@Логин", login);
                        int loginCount = (int)cmdCheck.ExecuteScalar();

                        if (loginCount > 0)
                        {
                            MessageBox.Show("Логин уже занят. Пожалуйста, выберите другой.");
                            return;
                        }
                    }

                    // 1. Сначала добавляем сотрудника в таблицу Сотрудник
                    string insertEmployeeQuery = @"
                    INSERT INTO [Сотрудник] ([Фамилия], [Имя], [Отчество]) VALUES (@Фамилия, @Имя, @Отчество)";

                    using (OleDbCommand cmdEmployee = new OleDbCommand(insertEmployeeQuery, connection, transaction))
                    {
                        cmdEmployee.Parameters.AddWithValue("@Фамилия", lastName);
                        cmdEmployee.Parameters.AddWithValue("@Имя", firstName);
                        cmdEmployee.Parameters.AddWithValue("@Отчество", middleName);
                        cmdEmployee.ExecuteNonQuery();
                    }

                    // Получаем ID только что добавленного сотрудника
                    string getLastIdQuery = "SELECT @@IDENTITY";
                    int employeeId;
                    using (OleDbCommand cmdGetId = new OleDbCommand(getLastIdQuery, connection, transaction))
                    {
                        employeeId = Convert.ToInt32(cmdGetId.ExecuteScalar());
                    }

                    // 2. Добавляем аккаунт с привязкой к сотруднику
                    string insertAccountQuery = @"INSERT INTO [Аккаунт] ([Телефон], [Логин], [Пароль], [Роли]) VALUES (@Телефон, @Логин, @Пароль, @Роли)";

                    using (OleDbCommand cmdAccount = new OleDbCommand(insertAccountQuery, connection, transaction))
                    {
                        cmdAccount.Parameters.AddWithValue("@Телефон", phone); // Сохраняем 10 цифр: 9674674434
                        cmdAccount.Parameters.AddWithValue("@Логин", login);
                        cmdAccount.Parameters.AddWithValue("@Пароль", password);
                        cmdAccount.Parameters.AddWithValue("@Роли", "employee");

                        int rowsAffected = cmdAccount.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            transaction.Commit();
                            MessageBox.Show("Регистрация прошла успешно!", "Ура! :)", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Переход на форму сотрудника
                            Сотрудник employeeForm = new Сотрудник(login);
                            employeeForm.Show();
                            this.Close();
                        }
                        else
                        {
                            transaction.Rollback();
                            MessageBox.Show("Ошибка при регистрации аккаунта.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Откатываем транзакцию при ошибке
                    if (transaction != null)
                    {
                        try { transaction.Rollback(); } catch { }
                    }

                    MessageBox.Show($"Ошибка при регистрации: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login_app loginForm = new Login_app();
            loginForm.Show();
            this.Close();
        }
    }
}