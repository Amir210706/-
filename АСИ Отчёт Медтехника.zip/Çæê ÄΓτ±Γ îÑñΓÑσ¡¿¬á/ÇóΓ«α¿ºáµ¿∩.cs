﻿using PK.controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Диплом;
using РК.controller;

namespace РК
{
    public partial class Authorization : Form
    {
        public Authorization()
        {
            InitializeComponent();
            label1.BackColor = System.Drawing.Color.Transparent;
            checkBox1.BackColor = System.Drawing.Color.Transparent;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Query command = new Query(connectionstring.connect);
            if (command.Autorization(login.Text, passw.Text))
            {
                string role = command.roleCheck(login.Text, passw.Text);
                string userLogin = login.Text;

                // Сначала показываем сообщение об успешной авторизации
                MessageBox.Show($"Добро пожаловать, {userLogin}!\nРоль: {role}",
                    "Успешная авторизация",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                // Затем открываем соответствующую форму в зависимости от роли
                if (role == "admin")
                {
                    Адмистрация form1 = new Адмистрация(userLogin);
                    form1.Show();
                    this.Close();
                }
                else if (role == "Director")
                {
                    Директор form5 = new Директор();
                    form5.Show();
                    this.Close();
                }
                else if (role == "employee")
                {
                    string employeeLogin = login.Text;
                    Сотрудник clientForm = new Сотрудник(employeeLogin);
                    clientForm.Show();
                    this.Close();
                }
                else if (role == "user")
                {
                    string userLogin1 = login.Text;
                    Клиент clientForm = new Клиент(userLogin1);
                    clientForm.Show();
                    this.Close();
                }
                else
                {
                    // Обработка случая, когда роль неизвестна
                    MessageBox.Show("Обнаружена неизвестная роль пользователя. Обратитесь к администратору.",
                        "Предупреждение",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    this.Close(); // Закрываем форму авторизации
                }
            }
            else
            {
                MessageBox.Show("Введён неверный логин или пароль",
                    "Ошибка авторизации",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login_app form8 = new Login_app();
            form8.Show();
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox1.Checked)
            {
                passw.UseSystemPasswordChar = false; 


            }
            else
            {
                passw.UseSystemPasswordChar = true;
                
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
