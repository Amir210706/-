﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;

namespace PK.controller
{
    internal class Query
    {
        OleDbConnection connection;
        OleDbCommand command;
        OleDbDataAdapter dataAdapter;
        DataTable bufferTable;
        public Query(string Conn)
        {
            connection = new OleDbConnection(Conn);
            bufferTable = new DataTable();
        }
        public bool Autorization(string user_login, string user_password)
        {
            connection.Open();
            command = new OleDbCommand("SELECT * FROM Аккаунт WHERE Логин = @login AND Пароль = @password", connection);
            command.Parameters.AddWithValue("@login", user_login);
            command.Parameters.AddWithValue("@password", user_password);

            OleDbDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                connection.Close();
                return true;
            }
            else
            {
                connection.Close();
                return false;
            }
        }
        public string roleCheck(string login, string password)
        {
            connection.Open();
            command = new OleDbCommand("SELECT * FROM Аккаунт WHERE Логин = @login AND Пароль = @password", connection);
            command.Parameters.AddWithValue("@login", login);
            command.Parameters.AddWithValue("@password", password);

            string role = null;
            OleDbDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                role = reader["Роли"].ToString();
            }
            connection.Close();
            return role;
        }
        public DataTable UpdatePerson()
        {
            connection.Open();
            dataAdapter = new OleDbDataAdapter("SELECT * FROM [Медтехника]", connection);
            bufferTable.Clear();
            dataAdapter.Fill(bufferTable);
            connection.Close();
            return bufferTable;
        }
        
        public void Add_Employee(string Surname, string name, string Middle_name, int Salary)
        {
            connection.Open();
            command = new OleDbCommand($"INSERT INTO [Сотрудник]([Фамилия], [Имя],[Отчество],[Зарплата]) VALUES([@Фамилия],[@Имя],[@Отчество],[@Зарплата])", connection);
            command.Parameters.AddWithValue("[Фамилия]", Surname);
            command.Parameters.AddWithValue("[Имя]", name);
            command.Parameters.AddWithValue("[Очество]", Middle_name);
            command.Parameters.AddWithValue("[Зарплата]", Salary);
            command.ExecuteNonQuery();
            connection.Close();
        }
        public void Add_Electrical_goods( string goods, int zena, int Quantity, string Description)
        {
            connection.Open();
            command = new OleDbCommand($"INSERT INTO [Медтехника]([Название_товара],[Цена],[Количество_Товаров],[Описание] ) VALUES([@Название_товара],[@Цена],[@Количество_Товаров],[@Описание])", connection);
            command.Parameters.AddWithValue("[Название_товара]", goods);
            command.Parameters.AddWithValue("[Цена]", zena);
            command.Parameters.AddWithValue("[Количество_Товаров]", Quantity);
            command.Parameters.AddWithValue("[Описание]", Description);
            command.ExecuteNonQuery();
            connection.Close();
        }

        public void Add_Sales(int productId, string company, string productName, decimal price, int quantity, string orderNumber, string status, DateTime orderDate, DateTime issueDate)
        {
           
            connection.Open();
            command = new OleDbCommand($"INSERT INTO [Заказы]([ID_Медтехника] [ID_Медтехника] [Заказчик],  [Название_товара],[Цена],[Количество],[Номерзаказа], [Статус], [Дата_оформления_заказа], [Дата_выдачи] ) VALUES([@ID_Медтехника] [@ID_Медтехника] [@Заказчик],[@Название_товара],[@Цена],[@Количество],[@Номерзаказа], [@Статус], [@Дата_оформления_заказа],[@Дата_выдачи]  )", connection);
            command.Parameters.AddWithValue("[ID_Медтехника]", productId);
         
            command.Parameters.AddWithValue("[Заказчик]", company);
            command.Parameters.AddWithValue("[Название_товара]", productName);
            command.Parameters.AddWithValue("[Цена]", price);
            command.Parameters.AddWithValue("[Количество]", quantity);
            command.Parameters.AddWithValue("[Статус]", status);
            command.Parameters.AddWithValue("[Номерзаказа]", orderNumber);
            command.Parameters.AddWithValue("[Дата_оформления_заказа]", orderDate);
            command.Parameters.AddWithValue("[Дата_выдачи]", issueDate);
            command.ExecuteNonQuery();
            connection.Close();
        }
        public void Add_account(string Telephone, string login, string parroli, string role)
        {
            connection.Open();
            command = new OleDbCommand($"INSERT INTO [Аккаунт]([Телефон],[Логин], [Пароль], [Роли]) VALUES([@Телефон],[@Логин], [@Пароль], [@Роли])", connection);
            command.Parameters.AddWithValue("[Телефон]", Telephone);
            command.Parameters.AddWithValue("[Логин]", login);
            command.Parameters.AddWithValue("[Пароль]", parroli);
            command.Parameters.AddWithValue("[Роли]", role);
            command.ExecuteNonQuery();
            connection.Close();
        }


        public void Delete4(int OrderID)
        {
            connection.Open();
            command = new OleDbCommand($"DELETE FROM [Продажи] WHERE [ID_Заказа] = {OrderID}", connection);
            command.ExecuteNonQuery();
            connection.Close();
        }
        public void Delete1(int IDemployee)
        {
            connection.Open();
            command = new OleDbCommand($"DELETE FROM [Сотрудник] WHERE [ID_сотрудника] = {IDemployee}", connection);
            command.ExecuteNonQuery();
            connection.Close();
        }
        public void Delete2(int IDkog_knigi)
        {
            connection.Open();
            command = new OleDbCommand($"DELETE FROM [Медтехники] WHERE [ID_Медтехника] = {IDkog_knigi}", connection);
            command.ExecuteNonQuery();
            connection.Close();
        }
        public void Delete3(int OrderID)
        {
            connection.Open();
            command = new OleDbCommand($"DELETE FROM [Аккаунт] WHERE [ID_Аккаунт] = {OrderID}", connection);
            command.ExecuteNonQuery();
            connection.Close();
        }

    }
}