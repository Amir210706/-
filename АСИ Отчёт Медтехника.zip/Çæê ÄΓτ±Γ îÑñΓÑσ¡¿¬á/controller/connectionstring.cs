﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
namespace РК.controller
{
    internal class connectionstring
    {
        public static string connect
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["РК.Properties.Settings.connect"].ConnectionString;
            }
        }
    }
}
