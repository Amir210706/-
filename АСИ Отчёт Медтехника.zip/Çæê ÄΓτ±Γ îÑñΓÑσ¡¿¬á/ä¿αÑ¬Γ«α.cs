﻿using PK.controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using РК.controller;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;



namespace РК
{
    public partial class Директор : Form
    {
        Query controller;
        public Директор()
        {
            InitializeComponent();
            this.Load += new EventHandler(Form5_Load);
            controller = new Query(connectionstring.connect);

            label1.Visible = false; textBox1.Visible = false;
            label2.Visible = false; textBox2.Visible = false;
            label3.Visible = false; textBox3.Visible = false;
            label4.Visible = false; textBox4.Visible = false;
        

            label7.Visible = false;

            label1.BackColor = System.Drawing.Color.Transparent;
            label2.BackColor = System.Drawing.Color.Transparent;
            label3.BackColor = System.Drawing.Color.Transparent;
            label4.BackColor = System.Drawing.Color.Transparent;
            label7.BackColor = System.Drawing.Color.Transparent;
            label6.BackColor = System.Drawing.Color.Transparent;
            label8.BackColor = System.Drawing.Color.Transparent;


            buttonExport.Visible = false;
            
            Change.Visible = false;

            buttonAnalyze.Visible = false;
    
        }




        private void LoadTableData(string tableName)
        {
            if (string.IsNullOrEmpty(tableName)) return;

            string path = Application.StartupPath + @"\Медтехника.accdb";
            string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    string query = $"SELECT * FROM [{tableName}]";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    dataGridView1.DataSource = table;

                    // Очищаем поля ввода
                    textBox1.Text = string.Empty;
                    textBox2.Text = string.Empty;
                    textBox3.Text = string.Empty;
                    textBox4.Text = string.Empty;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
                }
            }

            buttonExport.Visible = false;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            try
            {
                string path = Application.StartupPath + @"\Медтехника.accdb";
                string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                    comboBox1.Items.Clear();

                    foreach (DataRow row in schemaTable.Rows)
                    {
                        string tableType = row["TABLE_TYPE"].ToString();
                        string tableName = row["TABLE_NAME"].ToString();

                        if (tableType == "TABLE" && tableName != "Аккаунт")
                        {
                            comboBox1.Items.Add(tableName);
                        }
                    }
                }

                // Автовыбор первой таблицы и загрузка данных
                if (comboBox1.Items.Count > 0)
                {
                    comboBox1.SelectedIndex = 0; // Это автоматически вызовет comboBox1_SelectedIndexChanged
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }


        private void Exit_Click(object sender, EventArgs e)
        {
            Login_app form2 = new Login_app();
            form2.Show();
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedTable = comboBox1.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedTable)) return;

            if (selectedTable == "Сотрудник")
            {
                // Показываем поля для сотрудника
                label1.Visible = true; textBox1.Visible = true;
                label2.Visible = true; textBox2.Visible = true;
                label3.Visible = true; textBox3.Visible = true;
                label4.Visible = true; textBox4.Visible = true;
                label7.Visible = true;

                // Кнопки
                Change.Visible = true;
                buttonExport.Visible = false;
                buttonAnalyze.Visible = true;
                buttonAnalyze.Text = "Отчет по зарплате";

                // Подписи
                label8.Text = "Таблица Сотрудника";
                label1.Text = "Фамилия";
                label2.Text = "Имя";
                label3.Text = "Отчество";
                label4.Text = "Зарплата";

                //  Автозагрузка данных
                LoadTableData("Сотрудник");
            }
            else if (selectedTable == "Медтехника")
            {
                // Скрываем поля
                label1.Visible = false; textBox1.Visible = false;
                label2.Visible = false; textBox2.Visible = false;
                label3.Visible = false; textBox3.Visible = false;
                label4.Visible = false; textBox4.Visible = false;
                label7.Visible = false;

                // Кнопки
                Change.Visible = false;
                buttonExport.Visible = false;
                buttonAnalyze.Visible = false;

                label8.Text = "Таблица Медтехника";

                // Очищаем подписи
                label1.Text = label2.Text = label3.Text = label4.Text = string.Empty;

                //  Автозагрузка данных
                LoadTableData("Медтехника");
            }
            else if (selectedTable == "Заказы")
            {
                // Скрываем поля
                label1.Visible = false; textBox1.Visible = false;
                label2.Visible = false; textBox2.Visible = false;
                label3.Visible = false; textBox3.Visible = false;
                label4.Visible = false; textBox4.Visible = false;
                label7.Visible = false;

                // Кнопки
                Change.Visible = false;
                buttonExport.Visible = false;
                buttonAnalyze.Visible = true;
                buttonAnalyze.Text = "Показать аналитику заказов";

                label8.Text = "Таблица Заказов";

                // Очищаем подписи
                label1.Text = label2.Text = label3.Text = label4.Text = string.Empty;

                //  Автозагрузка данных
                LoadTableData("Заказы");
            }
        }

        private string GetReportTitle()
        {
            if (comboBox1.Text == "Сотрудник")
                return "Отчет по зарплате сотрудников";
            else if (comboBox1.Text == "Заказы")
                return "Аналитика заказов по датам";
            else
                return $"Отчет: {comboBox1.Text}";
        }

        private void buttonAnalyze_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Сотрудник")
            {
                buttonExport.Visible = true;

                string databasePath = Application.StartupPath + @"\Медтехника.accdb";
                string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={databasePath};Persist Security Info=False;";
                string query = "SELECT Фамилия, Имя, Отчество, Зарплата FROM Сотрудник";

                DataTable dt = new DataTable();

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                        adapter.Fill(dt);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при загрузке данных: " + ex.Message);
                        return;
                    }
                }

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Данные о сотрудниках отсутствуют.");
                    return;
                }

                // Создаем новую таблицу для отображения с форматированием
                DataTable displayTable = new DataTable();
                displayTable.Columns.Add("Фамилия", typeof(string));
                displayTable.Columns.Add("Имя", typeof(string));
                displayTable.Columns.Add("Отчество", typeof(string));
                displayTable.Columns.Add("Оклад", typeof(string));
                displayTable.Columns.Add("Налог (13%)", typeof(string));
                displayTable.Columns.Add("Зарплата", typeof(string));

                // Обработка данных и вычисления
                double totalSalarySum = 0;
                int count = 0;
                double totalTaxSum = 0;
                double taxRate = 0.13; // 13% налог

                // Сначала собираем сумму для расчета средней зарплаты
                foreach (DataRow row in dt.Rows)
                {
                    string salaryStr = row["Зарплата"].ToString();
                    salaryStr = salaryStr.Replace(" ", "").Replace("₽", "").Replace(",", ".");

                    if (double.TryParse(salaryStr, NumberStyles.Any, CultureInfo.InvariantCulture, out double salary))
                    {
                        totalSalarySum += salary;
                        totalTaxSum += salary * taxRate;
                        count++;
                    }
                }

                // Рассчитываем среднюю зарплату
                double averageSalary = count > 0 ? totalSalarySum / count : 0;
                string averageSalaryFormatted = $"{averageSalary:F2}₽";

                // Теперь заполняем таблицу отображения
                foreach (DataRow row in dt.Rows)
                {
                    string salaryStr = row["Зарплата"].ToString();
                    string originalSalaryStr = salaryStr; // Сохраняем оригинальный формат
                    salaryStr = salaryStr.Replace(" ", "").Replace("₽", "").Replace(",", ".");

                    double salary = 0;
                    double tax = 0;

                    if (double.TryParse(salaryStr, NumberStyles.Any, CultureInfo.InvariantCulture, out salary))
                    {
                        tax = salary * taxRate;
                    }

                    // Добавляем в таблицу для отображения
                    DataRow newRow = displayTable.NewRow();
                    newRow["Фамилия"] = row["Фамилия"].ToString();
                    newRow["Имя"] = row["Имя"].ToString();
                    newRow["Отчество"] = row["Отчество"].ToString();
                    newRow["Оклад"] = originalSalaryStr; // Оригинальный формат
                    newRow["Налог (13%)"] = $"{tax:F2}₽";
                    newRow["Зарплата"] = averageSalaryFormatted;
                    displayTable.Rows.Add(newRow);
                }

                // Добавляем итоговую строку
                DataRow totalRow = displayTable.NewRow();
                totalRow["Фамилия"] = "ИТОГО:";
                totalRow["Имя"] = "";
                totalRow["Отчество"] = "";
                totalRow["Оклад"] = $"{totalSalarySum:F2}₽";
                totalRow["Налог (13%)"] = $"{totalTaxSum:F2}₽";
                totalRow["Зарплата"] = averageSalaryFormatted;
                displayTable.Rows.Add(totalRow);

                // Вывод данных в DataGridView
                dataGridView1.DataSource = displayTable;

                // Подсвечиваем итоговую строку желтым цветом
                HighlightTotalRow(Color.Yellow);

                // Выводим среднюю зарплату в label
  
                // Сохраняем исходную таблицу для экспорта
                dataGridView1.Tag = dt;
            }

            else if (comboBox1.Text == "Заказы")
            {
                buttonExport.Visible = true;

                string databasePath = Application.StartupPath + @"\Медтехника.accdb";
                string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={databasePath};Persist Security Info=False;";

                // Исправленный запрос - преобразуем в числа в самом запросе
                string query = @"SELECT Дата_оформления_заказа AS Дата, COUNT(*) AS Количество_Заказов, SUM(Цена * Количество) AS Общая_Сумма, AVG(Цена * Количество) AS Средний_Чек FROM Заказы WHERE Дата_оформления_заказа IS NOT NULL GROUP BY Дата_оформления_заказа ORDER BY Дата_оформления_заказа DESC";

                DataTable dt = new DataTable();

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                        adapter.Fill(dt);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при загрузке аналитики заказов: " + ex.Message);
                        return;
                    }
                }

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Данные о заказах отсутствуют.");
                    return;
                }

                // Создаем новую таблицу для отображения с форматированием
                DataTable displayTable = new DataTable();
                displayTable.Columns.Add("Дата", typeof(string));
                displayTable.Columns.Add("Количество Заказов", typeof(int));
                displayTable.Columns.Add("Общая Сумма", typeof(string)); // Для отображения

              

                double totalRevenue = 0;
                int totalOrders = 0;

                // Сначала вычисляем общие показатели
                foreach (DataRow row in dt.Rows)
                {
                    decimal totalSum = 0;
                    if (row["Общая_Сумма"] != DBNull.Value && decimal.TryParse(row["Общая_Сумма"].ToString(), out totalSum))
                    {
                        totalRevenue += (double)totalSum;
                    }

                    int orderCount = 0;
                    if (row["Количество_Заказов"] != DBNull.Value && int.TryParse(row["Количество_Заказов"].ToString(), out orderCount))
                    {
                        totalOrders += orderCount;
                    }
                }

                // Расчет среднего чека по всем данным
                double averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
                string averageOrderValueFormatted = $"{averageOrderValue:N2} ₽";

                // Теперь заполняем таблицу отображения
                foreach (DataRow row in dt.Rows)
                {
                    decimal totalSum = 0;
                    //decimal avgCheck = 0;
                    int orderCount = 0;

                    // Парсим значения
                    if (row["Общая_Сумма"] != DBNull.Value)
                    {
                        decimal.TryParse(row["Общая_Сумма"].ToString(), out totalSum);
                    }

                    

                    if (row["Количество_Заказов"] != DBNull.Value)
                    {
                        int.TryParse(row["Количество_Заказов"].ToString(), out orderCount);
                    }

                    // Форматируем дату
                    string formattedDate = "";
                    if (row["Дата"] != DBNull.Value)
                    {
                        DateTime date;
                        if (DateTime.TryParse(row["Дата"].ToString(), out date))
                        {
                            formattedDate = date.ToString("dd.MM.yyyy");
                        }
                        else
                        {
                            formattedDate = row["Дата"].ToString();
                        }
                    }

                    // Добавляем в таблицу для отображения
                    DataRow newRow = displayTable.NewRow();
                    newRow["Дата"] = formattedDate;
                    newRow["Количество Заказов"] = orderCount;
                    newRow["Общая Сумма"] = $"{totalSum:N2} ₽";


                    displayTable.Rows.Add(newRow);
                }

                // Добавляем итоговую строку
                DataRow totalRow = displayTable.NewRow();
                totalRow["Дата"] = "ИТОГО:";
                totalRow["Количество Заказов"] = totalOrders;
                totalRow["Общая Сумма"] = $"{totalRevenue:N2} ₽";


                displayTable.Rows.Add(totalRow);

                // Отображаем таблицу с форматированием
                dataGridView1.DataSource = displayTable;

                // Подсвечиваем итоговую строку желтым цветом
                HighlightTotalRow(Color.Yellow);

   
                // Для экспорта можно сохранить оригинальные данные
                dataGridView1.Tag = dt;
            }
        }

        // Метод для подсветки итоговой строки
        // Метод для подсветки итоговой строки
        private void HighlightTotalRow(Color color)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                // Итоговая строка всегда последняя
                int lastRowIndex = dataGridView1.Rows.Count - 2;

                // Только желтый фон, без жирного шрифта
                dataGridView1.Rows[lastRowIndex].DefaultCellStyle.BackColor = color;
            }
        }

        private void Change_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "Сотрудник")
            {
                MessageBox.Show("Редактирование доступно только для таблицы 'Сотрудник'.");
                return;
            }

            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Пожалуйста, выберите строку для редактирования.");
                return;
            }

            int selectedId;
            try
            {
                selectedId = int.Parse(dataGridView1.CurrentRow.Cells["ID_сотрудника"].Value?.ToString() ?? "");
            }
            catch
            {
                MessageBox.Show("Ошибка получения ID выбранной записи.");
                return;
            }

            // Получение новых значений
            string Surname = textBox1.Text;
            string name = textBox2.Text;
            string Middle_name = textBox3.Text;

            if (!int.TryParse(textBox4.Text, out int Salary))
            {
                MessageBox.Show("Пожалуйста, введите числовое значение для зарплаты.");
                return;
            }

            // Обновление данных в базе данных
            string path = Application.StartupPath + @"\Медтехника.accdb";
            string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    string updateQuery = "UPDATE [Сотрудник] SET Фамилия = @Фамилия, Имя = @Имя, Отчество = @Отчество, Зарплата = @Зарплата WHERE ID_сотрудника = @ID_сотрудника";

                    using (OleDbCommand cmd = new OleDbCommand(updateQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@Фамилия", Surname);
                        cmd.Parameters.AddWithValue("@Имя", name);
                        cmd.Parameters.AddWithValue("@Отчество", Middle_name);
                        cmd.Parameters.AddWithValue("@Зарплата", Salary);
                        cmd.Parameters.AddWithValue("@ID_сотрудника", selectedId);

                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Данные успешно обновлены.");

                            // Обновляем таблицу после изменения
                            LoadTableData("Сотрудник");

                            // Очищаем поля
                            textBox1.Text = string.Empty;
                            textBox2.Text = string.Empty;
                            textBox3.Text = string.Empty;
                            textBox4.Text = string.Empty;
                        }
                        else
                        {
                            MessageBox.Show("Обновление не удалось. Проверьте выбранную запись.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при обновлении: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && comboBox1.Text == "Сотрудник")
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Фамилия"].Value.ToString();
                textBox2.Text = row.Cells["Имя"].Value.ToString();
                textBox3.Text = row.Cells["Отчество"].Value.ToString();
                textBox4.Text = row.Cells["Зарплата"].Value.ToString();
       
            }
            
        }

       

        private void buttonExport_Click(object sender, EventArgs e)
        {
            if (dataGridView1 == null || dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("Нет данных для экспорта.", "Информация",
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel 2007-2019 (*.xlsx)|*.xlsx|Excel 97-2003 (*.xls)|*.xls|Все файлы (*.*)|*.*";
            saveFileDialog.FilterIndex = 1;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.FileName = $"Отчет_{comboBox1.Text}_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string fileExtension = Path.GetExtension(saveFileDialog.FileName).ToLower();

                    if (fileExtension == ".xlsx")
                    {
                        ExportToExcelXlsx(dataGridView1, saveFileDialog.FileName);
                    }
                    else if (fileExtension == ".xls")
                    {
                        ExportToExcelXls(dataGridView1, saveFileDialog.FileName);
                    }
                    else
                    {
                        string newFilePath = Path.ChangeExtension(saveFileDialog.FileName, ".xlsx");
                        ExportToExcelXlsx(dataGridView1, newFilePath);
                    }

                    MessageBox.Show($"Файл успешно создан:\n{saveFileDialog.FileName}", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при экспорте: {ex.Message}","Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ExportToExcelXlsx(DataGridView dataGridView, string filePath)
        {
            //  ИЗМЕНЕНО: HDR=NO чтобы первая строка была данными, а не заголовками
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=NO\"";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();

                // Создаем таблицу с колонками F1, F2, F3... (стандартные имена при HDR=NO)
                string createTable = "CREATE TABLE [Отчет] (";
                int columnCount = 0;

                for (int i = 0; i < dataGridView.Columns.Count; i++)
                {
                    if (dataGridView.Columns[i].Visible)
                    {
                        createTable += $" [F{columnCount + 1}] VARCHAR(255),";
                        columnCount++;
                    }
                }
                createTable = createTable.TrimEnd(',') + ")";

                using (OleDbCommand command = new OleDbCommand(createTable, connection))
                {
                    command.ExecuteNonQuery();
                }

                //  СТРОКА 1: Название отчета (в первой ячейке, остальные пустые)
                string reportTitle = GetReportTitle();
                string insertTitleQuery = $"INSERT INTO [Отчет] VALUES ('{reportTitle.Replace("'", "''")}'";
                for (int i = 1; i < columnCount; i++)
                {
                    insertTitleQuery += ", ''";
                }
                insertTitleQuery += ")";

                using (OleDbCommand command = new OleDbCommand(insertTitleQuery, connection))
                {
                    command.ExecuteNonQuery();
                }

                //  СТРОКА 2: Заголовки столбцов (Фамилия, Имя, Отчество...)
                string insertHeadersQuery = "INSERT INTO [Отчет] VALUES (";
                int paramIndex = 0;
                List<OleDbParameter> headerParams = new List<OleDbParameter>();

                for (int j = 0; j < dataGridView.Columns.Count; j++)
                {
                    if (dataGridView.Columns[j].Visible)
                    {
                        insertHeadersQuery += $"@h{paramIndex},";
                        string headerText = CleanColumnName(dataGridView.Columns[j].HeaderText);
                        headerParams.Add(new OleDbParameter($"@h{paramIndex}", headerText));
                        paramIndex++;
                    }
                }
                insertHeadersQuery = insertHeadersQuery.TrimEnd(',') + ")";

                using (OleDbCommand command = new OleDbCommand(insertHeadersQuery, connection))
                {
                    command.Parameters.AddRange(headerParams.ToArray());
                    command.ExecuteNonQuery();
                }

                //  СТРОКА 3+: Основные данные
                for (int i = 0; i < dataGridView.Rows.Count; i++)
                {
                    if (dataGridView.Rows[i].IsNewRow) continue;

                    string insertQuery = "INSERT INTO [Отчет] VALUES (";
                    List<OleDbParameter> parameters = new List<OleDbParameter>();

                    paramIndex = 0;
                    for (int j = 0; j < dataGridView.Columns.Count; j++)
                    {
                        if (dataGridView.Columns[j].Visible)
                        {
                            insertQuery += $"@p{paramIndex},";
                            var value = dataGridView.Rows[i].Cells[j].Value;
                            parameters.Add(new OleDbParameter($"@p{paramIndex}", value?.ToString() ?? ""));
                            paramIndex++;
                        }
                    }
                    insertQuery = insertQuery.TrimEnd(',') + ")";

                    using (OleDbCommand command = new OleDbCommand(insertQuery, connection))
                    {
                        command.Parameters.AddRange(parameters.ToArray());
                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        private void ExportToExcelXls(DataGridView dataGridView, string filePath)
        {
            //  ИЗМЕНЕНО: HDR=NO чтобы первая строка была данными, а не заголовками
            string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" +
                                      filePath +
                                      ";Extended Properties=\"Excel 8.0;HDR=NO\"";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string createTable = "CREATE TABLE [Отчет] (";
                    int columnCount = 0;

                    for (int i = 0; i < dataGridView.Columns.Count; i++)
                    {
                        if (dataGridView.Columns[i].Visible)
                        {
                            createTable += $" [F{columnCount + 1}] VARCHAR(255),";
                            columnCount++;
                        }
                    }
                    createTable = createTable.TrimEnd(',') + ")";

                    using (OleDbCommand command = new OleDbCommand(createTable, connection))
                    {
                        command.ExecuteNonQuery();
                    }

                    //  СТРОКА 1: Название отчета
                    string reportTitle = GetReportTitle();
                    string insertTitleQuery = $"INSERT INTO [Отчет] VALUES ('{reportTitle.Replace("'", "''")}'";
                    for (int i = 1; i < columnCount; i++)
                    {
                        insertTitleQuery += ", ''";
                    }
                    insertTitleQuery += ")";

                    using (OleDbCommand command = new OleDbCommand(insertTitleQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }

                    //  СТРОКА 2: Заголовки столбцов
                    string insertHeadersQuery = "INSERT INTO [Отчет] VALUES (";
                    for (int j = 0; j < dataGridView.Columns.Count; j++)
                    {
                        if (dataGridView.Columns[j].Visible)
                        {
                            string headerText = CleanColumnName(dataGridView.Columns[j].HeaderText);
                            headerText = headerText.Replace("'", "''");
                            insertHeadersQuery += $"'{headerText}',";
                        }
                    }
                    insertHeadersQuery = insertHeadersQuery.TrimEnd(',') + ")";

                    using (OleDbCommand command = new OleDbCommand(insertHeadersQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }

                    //  СТРОКА 3+: Основные данные
                    for (int i = 0; i < dataGridView.Rows.Count; i++)
                    {
                        if (dataGridView.Rows[i].IsNewRow) continue;

                        string insertQuery = "INSERT INTO [Отчет] VALUES (";
                        for (int j = 0; j < dataGridView.Columns.Count; j++)
                        {
                            if (dataGridView.Columns[j].Visible)
                            {
                                var value = dataGridView.Rows[i].Cells[j].Value;
                                string stringValue = value?.ToString() ?? "";
                                stringValue = stringValue.Replace("'", "''");
                                insertQuery += $"'{stringValue}',";
                            }
                        }
                        insertQuery = insertQuery.TrimEnd(',') + ")";

                        using (OleDbCommand command = new OleDbCommand(insertQuery, connection))
                        {
                            command.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("не зарегистрирован") || ex.Message.Contains("not registered"))
                    {
                        throw new Exception("Для экспорта в формат .xls требуется Microsoft Jet OLEDB 4.0.\n" +"Используйте формат .xlsx или установите Microsoft Access Database Engine.");
                    }
                    throw;
                }
            }
        }

        private string CleanColumnName(string columnName)
        {
            if (string.IsNullOrEmpty(columnName))
                return "Column";

            char[] invalidChars = new char[] { '[', ']', '(', ')', '{', '}', '#', '!', '@', '$', '%', '^', '&', '*', '+', '=', '|', '\\', '/', '?', '<', '>', ',', ';', ':', '"', '\'' };

            foreach (char c in invalidChars)
            {
                columnName = columnName.Replace(c.ToString(), "");
            }

            columnName = columnName.Replace(" ", "_");

            if (char.IsDigit(columnName[0]))
            {
                columnName = "C_" + columnName;
            }

            return columnName.Trim();
        }
    }
}
