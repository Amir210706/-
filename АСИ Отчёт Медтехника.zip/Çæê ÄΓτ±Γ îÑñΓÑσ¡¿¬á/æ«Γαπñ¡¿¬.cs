﻿using PK.controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using РК.controller;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace РК
{
    public partial class Сотрудник : Form
    {
        Query controller;
        public Сотрудник(string employeeLogin)
        {
            InitializeComponent();
            this.Load += new EventHandler(Form4_Load);
            controller = new Query(connectionstring.connect);

            label_Name_Electrical_goods.Visible = false;
            textBox1.Visible = false;

            label_Price.Visible = false;
            textBox2.Visible = false;

            label_Product_Quantity.Visible = false;
            textBox3.Visible = false;

            label_Description.Visible = false;
            textBox4.Visible = false;

           
            label1.Visible = false;
            label2.Visible = false;
            label4.Visible = false;

        
            append.Visible = false;
            Delete.Visible = false;
            Change.Visible = false;

            label_Name_Electrical_goods.BackColor = System.Drawing.Color.Transparent;
            label_Price.BackColor = System.Drawing.Color.Transparent;
            label_Product_Quantity.BackColor = System.Drawing.Color.Transparent;
            label_Description.BackColor = System.Drawing.Color.Transparent;
            label1.BackColor = System.Drawing.Color.Transparent;
            label2.BackColor = System.Drawing.Color.Transparent;
            label4.BackColor = System.Drawing.Color.Transparent;
         
            label.BackColor = System.Drawing.Color.Transparent;
            labe.BackColor = System.Drawing.Color.Transparent;

            comboBox2.Visible = false;
            dateTimePicker1.Visible = false; // Изменено с textBox5 на dateTimePicker1

            
        }

        private void LoadTableData(string tableName)
        {
            if (string.IsNullOrEmpty(tableName))
            {
                dataGridView1.DataSource = null;
                return;
            }

            string path = Application.StartupPath + @"\Медтехника.accdb";
            string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    string query = $"SELECT * FROM [{tableName}]";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    dataGridView1.DataSource = table;

                    // Очищаем поля ввода
                    textBox1.Text = string.Empty;
                    textBox2.Text = string.Empty;
                    textBox3.Text = string.Empty;
                    textBox4.Text = string.Empty;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
                }
            }
        }
        private void Delete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.");
                return;
            }

            DialogResult result = MessageBox.Show(
                "Вы уверены, что хотите удалить выбранную запись?",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);

            if (result == DialogResult.No)
            {
                return;
            }

            try
            {
                if (comboBox1.Text == "Медтехника")
                {
                    controller.Delete2(int.Parse(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells["ID_Медтехника"].Value.ToString()));

                    LoadTableData("Медтехника");

                    MessageBox.Show("Запись успешно удалена.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при удалении: " + ex.Message);
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            try
            {
                string path = Application.StartupPath + @"\Медтехника.accdb";
                string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    comboBox1.Items.Clear();

                    foreach (DataRow row in schemaTable.Rows)
                    {
                        string tableType = row["TABLE_TYPE"].ToString();
                        string tableName = row["TABLE_NAME"].ToString();

                        if (tableType == "TABLE" && tableName != "Аккаунт" && !tableName.ToLower().Contains("сотрудник"))
                        {
                            comboBox1.Items.Add(tableName);
                        }
                    }
                }

                // 👇 АВТОВЫБОР ПЕРВОЙ ТАБЛИЦЫ И ЗАГРУЗКА ДАННЫХ
                if (comboBox1.Items.Count > 0)
                {
                    comboBox1.SelectedIndex = 0; // Автоматически вызовет comboBox1_SelectedIndexChanged
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }

            comboBox2.Items.Clear();
            comboBox2.Items.AddRange(new string[] { "Принят", "В обработке", "Выполнено", "Отказ" });
            comboBox2.SelectedIndex = 0;

            dateTimePicker1.Format = DateTimePickerFormat.Short;
            dateTimePicker1.Value = DateTime.Today;
        }

        private void append_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Медтехника")
            {
                if (!int.TryParse(textBox2.Text, out int value2) || !int.TryParse(textBox3.Text, out int value3))
                {
                    MessageBox.Show("Пожалуйста, введите числовые значения в поля 2 и 3.", "так нельзя >:(");
                    return;
                }

                controller.Add_Electrical_goods(textBox1.Text, value2, value3, textBox4.Text);
                ResettextBox1Text();
            }
        }

        private void ResettextBox1Text()
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox4.Text = string.Empty;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Login_app form2 = new Login_app();
            form2.Show();
            this.Close();
        }

        private void LoadSalesData()
        {
            string path = Application.StartupPath + @"\Медтехника.accdb";
            string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    string query = "SELECT * FROM Заказы";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                    DataTable salesTable = new DataTable();
                    adapter.Fill(salesTable);
                    dataGridView1.DataSource = salesTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки данных продаж: " + ex.Message);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedTable = comboBox1.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedTable)) return;

            if (selectedTable == "Медтехника")
            {
                // Показываем поля для Медтехники
                label_Name_Electrical_goods.Visible = true;
                textBox1.Visible = true;
                label_Price.Visible = true;
                textBox2.Visible = true;
                label_Product_Quantity.Visible = true;
                textBox3.Visible = true;
                label_Description.Visible = true;
                textBox4.Visible = true;

                label.Text = "таблица Медтехники";
                
                label1.Visible = false;
                label2.Visible = false;
                label4.Visible = true;

                // Кнопки
           
                append.Visible = true;
                Delete.Visible = true;
                Change.Visible = true;

                comboBox2.Visible = false;
                dateTimePicker1.Visible = false;

                // Подписи
                label_Name_Electrical_goods.Text = "Название Медтехника";
                label_Price.Text = "Цена";
                label_Product_Quantity.Text = "Количество товара";
                label_Description.Text = "Описание";

                // Автозагрузка данных
                LoadTableData("Медтехника");
            }
            else if (selectedTable == "Заказы")
            {
                // Скрываем поля Медтехники
                label_Name_Electrical_goods.Visible = false;
                textBox1.Visible = false;
                label_Price.Visible = false;
                textBox2.Visible = false;
                label_Product_Quantity.Visible = false;
                textBox3.Visible = false;
                label_Description.Visible = false;
                textBox4.Visible = false;

                label1.Visible = true;
                label2.Visible = true;
                label4.Visible = true;
                label.Text = "таблица Заказов";
             
                // Кнопки
               
                append.Visible = false;
                Delete.Visible = false;
                Change.Visible = true;

                // Поля для заказов
                label1.Text = "Статус";
                label2.Text = "Дата Выдача";
                comboBox2.Visible = true;
                dateTimePicker1.Visible = true;

                // Автозагрузка данных
                LoadTableData("Заказы");
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && comboBox1.Text == "Медтехника")
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Название_товара"].Value.ToString();
                textBox2.Text = row.Cells["Цена"].Value.ToString();
                textBox3.Text = row.Cells["Количество_Товаров"].Value.ToString();
                textBox4.Text = row.Cells["Описание"].Value.ToString();
            }
            else if (e.RowIndex >= 0 && comboBox1.Text == "Заказы")
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Заполняем статус
                if (row.Cells["Статус"].Value != null)
                {
                    string status = row.Cells["Статус"].Value.ToString();
                    comboBox2.SelectedItem = status;
                }

                // Заполняем дату выдачи
                if (row.Cells["Дата_выдачи"].Value != null)
                {
                    if (DateTime.TryParse(row.Cells["Дата_выдачи"].Value.ToString(), out DateTime dateValue))
                    {
                        dateTimePicker1.Value = dateValue;
                    }
                    else
                    {
                        dateTimePicker1.Value = DateTime.Today;
                    }
                }
            }
        }

        private void Change_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Медтехника")
            {
                ChangeMedicalEquipment();
            }
            else if (comboBox1.Text == "Заказы")
            {
                ChangeOrder();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите таблицу для изменения данных.");
            }
        }

        private void ChangeMedicalEquipment()
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Пожалуйста, выберите строку для редактирования.");
                return;
            }

            int selectedId;
            try
            {
                selectedId = int.Parse(dataGridView1.CurrentRow.Cells["ID_Медтехника"].Value.ToString());
            }
            catch
            {
                MessageBox.Show("Ошибка получения ID выбранной записи.");
                return;
            }

            string goods = textBox1.Text;
            string zena = textBox2.Text;
            string Quantity = textBox3.Text;
            string Description = textBox4.Text;

            string path = Application.StartupPath + @"\Медтехника.accdb";
            string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    string updateQuery = $"UPDATE [Медтехника] SET Название_товара = @Название_товара, Цена = @Цена, Количество_Товаров = @Количество_Товаров, Описание = @Описание WHERE ID_Медтехника = @ID_Медтехника";
                    using (OleDbCommand cmd = new OleDbCommand(updateQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@Название_товара", goods);
                        cmd.Parameters.AddWithValue("@Цена", zena);
                        cmd.Parameters.AddWithValue("@Количество_Товаров", Quantity);
                        cmd.Parameters.AddWithValue("@Описание", Description);
                        cmd.Parameters.AddWithValue("@ID_Медтехника", selectedId);

                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Данные успешно обновлены.");

                            textBox1.Text = string.Empty;
                            textBox2.Text = string.Empty;
                            textBox3.Text = string.Empty;
                            textBox4.Text = string.Empty;
                        }
                        else
                        {
                            MessageBox.Show("Обновление не удалось. Проверьте выбранную запись.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при обновлении: " + ex.Message);
                }
            }
        }

        private void ChangeOrder()
        {
            if (comboBox1.Text != "Заказы")
            {
                MessageBox.Show("Для изменения заказов выберите таблицу 'Заказы'.");
                return;
            }

            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.Index < 0)
            {
                MessageBox.Show("Пожалуйста, выберите запись для изменения.");
                return;
            }

            DataGridViewRow currentRow = dataGridView1.CurrentRow;

            object orderIdObj = currentRow.Cells["ID_Заказа"].Value;
            if (orderIdObj == null)
            {
                orderIdObj = currentRow.Cells["ID"].Value;
            }

            if (orderIdObj == null)
            {
                MessageBox.Show("Не удалось определить ID выбранного заказа.");
                return;
            }

            int orderId;
            if (!int.TryParse(orderIdObj.ToString(), out orderId))
            {
                MessageBox.Show("Некорректный ID заказа.");
                return;
            }

            // Проверяем, что хотя бы одно поле для изменения заполнено
            bool changeStatus = comboBox2.SelectedItem != null;
            bool changeDate = true; // DateTimePicker всегда имеет значение

            if (!changeStatus && !changeDate)
            {
                MessageBox.Show("Заполните поле даты или выберите статус для изменения.");
                return;
            }

            // Получаем новую дату из DateTimePicker
            DateTime newDate = dateTimePicker1.Value;

            // Получение нового статуса
            string newStatus = changeStatus ? comboBox2.SelectedItem.ToString() : null;

            // Обновление в базе данных
            string path = Application.StartupPath + @"\Медтехника.accdb";
            string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path}";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    StringBuilder updateQuery = new StringBuilder("UPDATE Заказы SET ");
                    List<OleDbParameter> parameters = new List<OleDbParameter>();

                    bool firstField = true;

                    if (changeStatus)
                    {
                        updateQuery.Append("Статус = @Status");
                        parameters.Add(new OleDbParameter("@Status", newStatus));
                        firstField = false;
                    }

                    if (changeDate)
                    {
                        if (!firstField) updateQuery.Append(", ");
                        updateQuery.Append("Дата_выдачи = @NewDate");
                        parameters.Add(new OleDbParameter("@NewDate", newDate));
                    }

                    updateQuery.Append(" WHERE ID_Заказа = @OrderID");
                    parameters.Add(new OleDbParameter("@OrderID", orderId));

                    using (OleDbCommand command = new OleDbCommand(updateQuery.ToString(), connection))
                    {
                        foreach (var param in parameters)
                        {
                            command.Parameters.Add(param);
                        }

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            StringBuilder message = new StringBuilder("Данные заказа успешно обновлены.\n");

                            if (changeStatus)
                            {
                                message.AppendLine($"Новый статус: {newStatus}");
                            }
                            if (changeDate)
                            {
                                message.AppendLine($"Новая дата выдачи: {newDate.ToShortDateString()}");
                            }

                            MessageBox.Show(message.ToString());

                            // Обновляем данные в таблице
                            LoadTableData("Заказы");

                            // Сбрасываем значения
                            comboBox2.SelectedIndex = 0;
                            dateTimePicker1.Value = DateTime.Today; // Сбрасываем на сегодняшнюю дату
                        }
                        else
                        {
                            MessageBox.Show("Запись не найдена или данные не изменены.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении заказа: {ex.Message}");
                }
            }
        }
    }
}
