﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace РК
{
    public partial class Клиент : Form
    {
        //  Константы для имён столбцов товаров
        private const string COL_ID = "ID_Медтехника";
        private const string COL_NAME = "Название";
        private const string COL_PRICE = "Цена";
        private const string COL_QUANTITY = "Количество";

        // Константы для таблицы заказов
        private const string COL_ORDER_NUM = "Номерзаказа";
        private const string COL_ORDER_PRODUCT = "Название_товара";
        private const string COL_ORDER_PRICE = "Цена";
        private const string COL_ORDER_QTY = "Количество";
        private const string COL_ORDER_TOTAL = "Сумма";
        private const string COL_ORDER_STATUS = "Статус";
        private const string COL_ORDER_DATE = "Дата_оформления_заказа";

        private DataTable корзинаTable = new DataTable();
        private decimal общаяСтоимость = 0m;
        private string loggedInUserLogin = "";
        private string текущийНомерЗаказа = "";

        //  Путь к БД вынесен в константу
        private const string DB_PATH = @"\Медтехника.accdb";
        private const string DB_CONNECTION_PROVIDER = "Microsoft.ACE.OLEDB.12.0";

        public Клиент(string userLogin)
        {
            InitializeComponent();
            loggedInUserLogin = userLogin;
            InitializeCartGrid();
        }

        //  Настройка корзины
        private void InitializeCartGrid()
        {
            корзинаTable.Columns.Add(COL_ID, typeof(int));
            корзинаTable.Columns.Add(COL_NAME, typeof(string));
            корзинаTable.Columns.Add(COL_PRICE, typeof(decimal));
            корзинаTable.Columns.Add(COL_QUANTITY, typeof(int));

            dataGridView2.AutoGenerateColumns = false;
            dataGridView2.Columns.Clear();
            dataGridView2.DataSource = корзинаTable;
            dataGridView2.ReadOnly = true;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView2.AllowUserToDeleteRows = false;

            AddGridColumn(dataGridView2, COL_ID, "ID", 50);
            AddGridColumn(dataGridView2, COL_NAME, "Название товара", 400);
            AddGridColumn(dataGridView2, COL_PRICE, "Цена", 70);
            AddGridColumn(dataGridView2, COL_QUANTITY, "Количество", 70);
        }

        // Вспомогательный метод для добавления столбцов
        private void AddGridColumn(DataGridView grid, string dataProperty, string header, int width)
        {
            if (grid == null) return;

            var column = new DataGridViewTextBoxColumn
            {
                DataPropertyName = dataProperty,
                HeaderText = header,
                Width = width,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleLeft }
            };
            grid.Columns.Add(column);
        }

        //  Получение строки подключения
        private string GetConnectionString()
        {
            string path = Application.StartupPath + DB_PATH;
            return $@"Provider={DB_CONNECTION_PROVIDER};Data Source={path}";
        }

        // Кнопка "Выйти"
        private void button4_Click(object sender, EventArgs e)
        {
            var form2 = new Login_app();
            form2.Show();
            this.Close();
        }

        // Кнопка "Загрузить товары"
        private void button1_Click(object sender, EventArgs e)
        {
            LoadProductsToGrid();
        }

        //  Загрузка товаров в DataGridView
        private void LoadProductsToGrid()
        {
            string query = "SELECT [ID_Медтехника], [Название_товара], [Цена], [Количество_Товаров], [Описание] FROM [Медтехника]";

            try
            {
                using (OleDbConnection connection = new OleDbConnection(GetConnectionString()))
                {
                    connection.Open();
                    DataTable table = new DataTable();

                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection))
                    {
                        adapter.Fill(table);
                    }

                    dataGridView1.AutoGenerateColumns = false;
                    dataGridView1.Columns.Clear();
                    dataGridView1.DataSource = table;
                    dataGridView1.ReadOnly = true;
                    dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

                    AddGridColumn(dataGridView1, "ID_Медтехника", "ID", 50);
                    AddGridColumn(dataGridView1, "Название_товара", "Название товара", 400);
                    AddGridColumn(dataGridView1, "Цена", "Цена", 70);
                    AddGridColumn(dataGridView1, "Количество_Товаров", "Количество", 70);
                    AddGridColumn(dataGridView1, "Описание", "Описание", 1100);
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка загрузки товаров: {ex.Message}");
            }
        }

        // Кнопка "Добавить в корзину"
        private void button2_Click(object sender, EventArgs e)
        {
            AddSelectedProductToCart();
        }

        //  Добавление товара в корзину
        private void AddSelectedProductToCart()
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите товар для добавления в корзину.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                var row = dataGridView1.SelectedRows[0].Cells;

                int id = Convert.ToInt32(row[0].Value);
                string название = row[1].Value?.ToString() ?? "Без названия";
                decimal цена = Convert.ToDecimal(row[2].Value);
                int наСкладе = Convert.ToInt32(row[3].Value);

                DataRow[] found = корзинаTable.Select($"{COL_ID} = {id}");

                if (found.Length > 0)
                {
                    int текущее = Convert.ToInt32(found[0][COL_QUANTITY]);
                    if (текущее + 1 > наСкладе)
                    {
                        MessageBox.Show($"Максимум доступно: {наСкладе} шт.", "Лимит", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    found[0][COL_QUANTITY] = текущее + 1;
                }
                else
                {
                    if (наСкладе <= 0)
                    {
                        MessageBox.Show("Товара нет в наличии!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    корзинаTable.Rows.Add(id, название, цена, 1);
                }

                UpdateTotalCost();
                dataGridView2.Refresh();
            }
            catch (FormatException)
            {
                ShowError("Неверный формат данных в таблице товаров.");
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка добавления в корзину: {ex.Message}");
            }
        }

        //  Удаление товара из корзины
        private void RemoveFromCart()
        {
            if (dataGridView2.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите товар в корзине для удаления.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (корзинаTable.Rows.Count == 0)
            {
                MessageBox.Show("Корзина пуста.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                int rowIndex = dataGridView2.SelectedRows[0].Index;
                int id = Convert.ToInt32(корзинаTable.Rows[rowIndex][0]);
                DataRow[] found = корзинаTable.Select($"ID_Медтехника = {id}");

                if (found.Length > 0)
                {
                    int текущееКоличество = Convert.ToInt32(found[0][3]);

                    if (текущееКоличество > 1)
                    {
                        found[0][3] = текущееКоличество - 1;
                    }
                    else
                    {
                        корзинаTable.Rows.Remove(found[0]);
                    }

                    UpdateTotalCost();
                    dataGridView2.Refresh();
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка удаления из корзины: {ex.Message}");
            }
        }

        // Кнопка "Удалить из корзины"
        private void button6_Click(object sender, EventArgs e)
        {
            RemoveFromCart();
        }

        // Обработчик нажатия клавиш в dataGridView2 (корзина)
        private void dataGridView2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete && dataGridView2.SelectedRows.Count > 0)
            {
                e.SuppressKeyPress = true;
                RemoveFromCart();
            }
        }

        // Обновление общей стоимости
        private void UpdateTotalCost()
        {
            общаяСтоимость = 0m;
            foreach (DataRow row in корзинаTable.Rows)
            {
                decimal price = row[COL_PRICE] != DBNull.Value ? Convert.ToDecimal(row[COL_PRICE]) : 0m;
                int qty = row[COL_QUANTITY] != DBNull.Value ? Convert.ToInt32(row[COL_QUANTITY]) : 0;
                общаяСтоимость += price * qty;
            }

            labelTotalCost.Text = $"Общая стоимость: {общаяСтоимость:C}";
        }

        // Кнопка "Оформить заказ"
        private void button3_Click(object sender, EventArgs e)
        {
            ProcessOrder();
        }

        //  Оформление заказа
        private void ProcessOrder()
        {
            if (корзинаTable.Rows.Count == 0)
            {
                MessageBox.Show("Ваша корзина пуста.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                using (OleDbConnection checkConnection = new OleDbConnection(GetConnectionString()))
                {
                    checkConnection.Open();
                    foreach (DataRow cartRow in корзинаTable.Rows)
                    {
                        int productId = Convert.ToInt32(cartRow[COL_ID]);
                        int cartQty = Convert.ToInt32(cartRow[COL_QUANTITY]);

                        string checkQuery = "SELECT [Количество_Товаров] FROM [Медтехника] WHERE [ID_Медтехника] = @ID";
                        using (OleDbCommand checkCmd = new OleDbCommand(checkQuery, checkConnection))
                        {
                            checkCmd.Parameters.AddWithValue("@ID", productId);
                            object checkResult = checkCmd.ExecuteScalar();
                            if (checkResult != null && checkResult != DBNull.Value)
                            {
                                int available = Convert.ToInt32(checkResult);
                                if (cartQty > available)
                                {
                                    string productName = cartRow[COL_NAME]?.ToString() ?? "Товар";
                                    MessageBox.Show($"Недостаточно товара \"{productName}\" на складе!\nЗапрошено: {cartQty}, доступно: {available}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка проверки наличия товара: {ex.Message}");
                return;
            }

            var result = MessageBox.Show($"Оформить заказ на сумму {общаяСтоимость:C}?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result != DialogResult.Yes) return;

            текущийНомерЗаказа = GenerateOrderNumber();
            DateTime сейчас = DateTime.Now;

            try
            {
                using (OleDbConnection connection = new OleDbConnection(GetConnectionString()))
                {
                    connection.Open();

                    using (OleDbTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            foreach (DataRow row in корзинаTable.Rows)
                            {
                                SaveOrderItem(connection, transaction, row, текущийНомерЗаказа, сейчас);
                                UpdateStockQuantity(connection, transaction,
                                    Convert.ToInt32(row[COL_ID]),
                                    Convert.ToInt32(row[COL_QUANTITY]));
                            }

                            transaction.Commit();
                            ClearCart();
                            LoadProductsToGrid();

                            MessageBox.Show($"✓ Заказ оформлен!\nНомер: {текущийНомерЗаказа}", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка оформления заказа: {ex.Message}");
            }
        }

        //  Сохранение одной позиции заказа
        private void SaveOrderItem(OleDbConnection connection, OleDbTransaction transaction,
            DataRow cartRow, string orderNumber, DateTime orderDate)
        {
            string query = @"INSERT INTO [Заказы]([ID_Медтехника], [Заказчик], [Название_товара], [Цена], [Количество], [Номерзаказа], [Статус], [Дата_оформления_заказа], [Дата_выдачи]) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            using (OleDbCommand cmd = new OleDbCommand(query, connection, transaction))
            {
                cmd.Parameters.Add("?", OleDbType.Integer).Value = Convert.ToInt32(cartRow[COL_ID]);
                cmd.Parameters.Add("?", OleDbType.VarChar, 100).Value = loggedInUserLogin ?? "";
                cmd.Parameters.Add("?", OleDbType.VarChar, 255).Value = cartRow[COL_NAME]?.ToString() ?? "";
                cmd.Parameters.Add("?", OleDbType.Currency).Value = Convert.ToDecimal(cartRow[COL_PRICE]);
                cmd.Parameters.Add("?", OleDbType.Integer).Value = Convert.ToInt32(cartRow[COL_QUANTITY]);
                cmd.Parameters.Add("?", OleDbType.VarChar, 50).Value = orderNumber;
                cmd.Parameters.Add("?", OleDbType.VarChar, 50).Value = "В обработке";
                cmd.Parameters.Add("?", OleDbType.Date).Value = orderDate.Date;
                cmd.Parameters.Add("?", OleDbType.Date).Value = DateTime.MinValue;

                cmd.ExecuteNonQuery();
            }
        }

        //  Очистка корзины
        private void ClearCart()
        {
            корзинаTable.Rows.Clear();
            общаяСтоимость = 0m;
            UpdateTotalCost();
            dataGridView2.Refresh();
        }

        //  Генерация номера заказа
        private string GenerateOrderNumber()
        {
            return Guid.NewGuid().ToString("N").Substring(0, 12).ToUpper();
        }

        //  Вспомогательный метод для показа ошибок
        private void ShowError(string message)
        {
            MessageBox.Show(message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Загрузка формы
        private void Клиент_Load(object sender, EventArgs e)
        {
            this.Width = 1300;
            this.Height = 660;
            this.StartPosition = FormStartPosition.CenterScreen;

            LoadProductsToGrid();
            dataGridView2.KeyDown += dataGridView2_KeyDown;

            // Безопасная подписка на события (защита от NullReferenceException)
            if (dataGridViewOrders != null)
            {
                dataGridViewOrders.CellDoubleClick += dataGridViewOrders_CellDoubleClick;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        //  Обработка двойного клика по товару
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                dataGridView1.Rows[e.RowIndex].Selected = true;
                AddSelectedProductToCart();
            }
        }

        /// <summary>
        /// Загружает все заказы текущего пользователя из БД
        /// </summary>
        private void LoadUserOrders()
        {
            // ЗАЩИТА ОТ NullReferenceException
            if (dataGridViewOrders == null)
            {
                ShowError("DataGridView 'dataGridViewOrders' не найден!\n\n" +
                         "Решение:\n" +
                         "1. Откройте форму в дизайнере\n" +
                         "2. Добавьте новый DataGridView\n" +
                         "3. Назовите его 'dataGridViewOrders'\n" +
                         "4. Сохраните форму");
                return;
            }

            if (string.IsNullOrWhiteSpace(loggedInUserLogin))
            {
                ShowError("Пользователь не авторизован.");
                return;
            }

            string query = @"SELECT [ID_Заказа], [Номерзаказа], [Название_товара], [Цена], [Количество], 
                                    ([Цена] * [Количество]) AS [Сумма],  [Дата_оформления_заказа] 
                             FROM [Заказы] 
                             WHERE [Заказчик] = @Login 
                             ORDER BY [Дата_оформления_заказа] DESC";

            try
            {
                using (OleDbConnection connection = new OleDbConnection(GetConnectionString()))
                {
                    connection.Open();
                    DataTable ordersTable = new DataTable();

                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection))
                    {
                        adapter.SelectCommand.Parameters.AddWithValue("@Login", loggedInUserLogin);
                        adapter.Fill(ordersTable);
                    }

                    dataGridViewOrders.AutoGenerateColumns = false;
                    dataGridViewOrders.Columns.Clear();
                    dataGridViewOrders.DataSource = ordersTable;

                    AddGridColumn(dataGridViewOrders, COL_ORDER_NUM, "№ заказа", 100);
                    AddGridColumn(dataGridViewOrders, COL_ORDER_PRODUCT, "Товар", 300);
                    AddGridColumn(dataGridViewOrders, COL_ORDER_PRICE, "Цена", 80);
                    AddGridColumn(dataGridViewOrders, COL_ORDER_QTY, "Кол-во", 60);
                    AddGridColumn(dataGridViewOrders, COL_ORDER_TOTAL, "Сумма", 80);

                    AddGridColumn(dataGridViewOrders, COL_ORDER_DATE, "Дата", 120);

                    // Форматирование столбцов
                    if (dataGridViewOrders.Columns.Contains(COL_ORDER_PRICE))
                        dataGridViewOrders.Columns[COL_ORDER_PRICE].DefaultCellStyle.Format = "C";
                    if (dataGridViewOrders.Columns.Contains(COL_ORDER_TOTAL))
                        dataGridViewOrders.Columns[COL_ORDER_TOTAL].DefaultCellStyle.Format = "C";
                    if (dataGridViewOrders.Columns.Contains(COL_ORDER_DATE))
                        dataGridViewOrders.Columns[COL_ORDER_DATE].DefaultCellStyle.Format = "dd.MM.yyyy";
                }

                int count = dataGridViewOrders.Rows.Count;
                MessageBox.Show($"Загружено заказов: {count}", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка загрузки заказов: {ex.Message}");
            }
        }

        /// <summary>
        /// Обработчик двойного клика по заказу
        /// </summary>
        private void dataGridViewOrders_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridViewOrders != null)
            {
                var row = dataGridViewOrders.Rows[e.RowIndex].Cells;
                string orderNum = row[COL_ORDER_NUM].Value?.ToString();
                string product = row[COL_ORDER_PRODUCT].Value?.ToString();
                string status = row[COL_ORDER_STATUS].Value?.ToString();
                decimal total = row[COL_ORDER_TOTAL].Value != null ? Convert.ToDecimal(row[COL_ORDER_TOTAL].Value) : 0m;

                MessageBox.Show(
                    $"Заказ №{orderNum}\n" +
                    $"Товар: {product}\n" +
                    $"Статус: {status}\n" +
                    $"Итого: {total:C}",
                    "Детали заказа",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        // Кнопка "Мои заказы"
        private void buttonMyOrders_Click(object sender, EventArgs e)
        {
            LoadUserOrders();
        }

        /// <summary>
        /// Добавление товара в таблицу [Медтехники]
        /// </summary>
        public bool Add_Medical_equipment(string goods, decimal zena, int Quantity, string Description)
        {
            if (string.IsNullOrWhiteSpace(goods))
            {
                ShowError("Название товара не может быть пустым.");
                return false;
            }
            if (zena < 0)
            {
                ShowError("Цена не может быть отрицательной.");
                return false;
            }
            if (Quantity < 0)
            {
                ShowError("Количество не может быть отрицательным.");
                return false;
            }

            string query = @"INSERT INTO [Медтехника]([Название_товара], [Цена], [Количество_Товаров], [Описание])  VALUES (@Название_товара, @Цена, @Количество_Товаров, @Описание)";

            try
            {
                using (OleDbConnection connection = new OleDbConnection(GetConnectionString()))
                {
                    connection.Open();

                    using (OleDbCommand cmd = new OleDbCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@Название_товара", goods);
                        cmd.Parameters.AddWithValue("@Цена", zena);
                        cmd.Parameters.AddWithValue("@Количество_Товаров", Quantity);
                        cmd.Parameters.AddWithValue("@Описание", Description ?? string.Empty);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Товар успешно добавлен!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Добавление заказа — публичный метод
        /// </summary>
        public bool Add_Order(int productId, string company, string productName, decimal price, int quantity, string status, DateTime orderDate, DateTime issueDate)
        {
            string orderNumber = GenerateOrderNumber();

            string query = @"INSERT INTO [Заказы] ([ID_Медтехника], [Компание], [Название_товара], [Цена], [Количество], [Номерзаказа], [Статус], [Дата_оформления_заказа], [Дата_выдачи])  VALUES (@ID_Медтехника, @Компание, @Название_товара, @Цена, @Количество, @Номерзаказа, @Статус, @Дата_оформления_заказа, @Дата_выдачи)";

            try
            {
                using (OleDbConnection connection = new OleDbConnection(GetConnectionString()))
                {
                    connection.Open();

                    using (OleDbCommand cmd = new OleDbCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@ID_Медтехника", productId);
                        cmd.Parameters.AddWithValue("@Компание", company);
                        cmd.Parameters.AddWithValue("@Название_товара", productName);
                        cmd.Parameters.AddWithValue("@Цена", price);
                        cmd.Parameters.AddWithValue("@Количество", quantity);
                        cmd.Parameters.AddWithValue("@Номерзаказа", orderNumber);
                        cmd.Parameters.AddWithValue("@Статус", status);
                        cmd.Parameters.AddWithValue("@Дата_оформления_заказа", orderDate);
                        cmd.Parameters.AddWithValue("@Дата_выдачи", issueDate);

                        cmd.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка добавления заказа: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Обёртка для совместимости
        /// </summary>
        [Obsolete("Используйте Add_Order с параметрами DateTime")]
        public bool Add_Sales(int productId, int employeeId, string company, string productName, decimal price, int quantity, string status, int orderDateOADate, string issueDateStr)
        {
            DateTime orderDate = orderDateOADate > 0 ? DateTime.FromOADate(orderDateOADate) : DateTime.Now;
            DateTime issueDate = !string.IsNullOrEmpty(issueDateStr) ? DateTime.Parse(issueDateStr) : orderDate.AddDays(3);

            return Add_Order(productId, company, productName, price, quantity, status, orderDate, issueDate);
        }

        //  Метод для обновления количества на складе
        private void UpdateStockQuantity(OleDbConnection connection, OleDbTransaction transaction, int productId, int soldQuantity)
        {
            string query = "UPDATE [Медтехника] SET [Количество_Товаров] = [Количество_Товаров] - @Qty WHERE [ID_Медтехника] = @ID";

            using (OleDbCommand cmd = new OleDbCommand(query, connection, transaction))
            {
                cmd.Parameters.AddWithValue("@Qty", soldQuantity);
                cmd.Parameters.AddWithValue("@ID", productId);
                cmd.ExecuteNonQuery();
            }
        }
    }
}

